<template>
    <div>
        <h1>医生管理</h1>
    </div>
</template>
<script>
export default {
  data () {
    return {
    
    };
  },
    methods:{
    
    }
}
</script>
<style lang='less' scoped>
    
</style>