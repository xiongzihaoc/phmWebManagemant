<template>
    <div>
        <h1>患者管理</h1>
    </div>
</template>
<script>
export default {
  data () {
    return {
    
    };
  },
    methods:{
    
    }
}
</script>
<style lang='less' scoped>
    
</style>