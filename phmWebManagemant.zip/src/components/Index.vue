<template>
  <div>
    <h3>Welcome To Index</h3>
    <img src="../assets/images/angry.gif" alt />
  </div>
</template>
<script>
export default {
  data() {
    return {};
  },
  methods: {}
};
</script>
<style lang='less' scoped>
img {
  display: block;
  margin-left: 40%;
}
h3 {
  font-weight: 700;
  font-size: 80px;
  color: #eee;
  text-align: center;
  margin: 50px 180px 0 0;
}
h3:hover {
  color: #000;
}
</style>